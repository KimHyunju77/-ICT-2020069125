package com.example.practicecalculator2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
import net.objecthunter.exp4j.Expression
import net.objecthunter.exp4j.ExpressionBuilder
import java.lang.Exception

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /**
         *
        1. 숫자 버튼을 클릭하면 화면에 표시가된다 (0은 숫자가 0인상태에서 눌러도 반응하지 않는다)
        2. 1 + 2 = 을하면 3이 표시된다
        3. 1 + 2 + 을하면 화면에 중간과정의 값인 3이 표시되며  그 후 3 = 을 누르면 6이 표시된다
        4. 사칙연산으로 확장한다
         */


        //numbers
        button1.setOnClickListener { appendOnExpresstion("1", true)}
        button2.setOnClickListener { appendOnExpresstion("2", true)}
        button3.setOnClickListener { appendOnExpresstion("3", true)}
        button4.setOnClickListener { appendOnExpresstion("4", true)}
        button5.setOnClickListener { appendOnExpresstion("5", true)}
        button6.setOnClickListener { appendOnExpresstion("6", true)}
        button7.setOnClickListener { appendOnExpresstion("7", true)}
        button8.setOnClickListener { appendOnExpresstion("8", true)}
        button9.setOnClickListener { appendOnExpresstion("9", true)}
        button0.setOnClickListener { appendOnExpresstion("0 ", true)}
        pointBtn.setOnClickListener { appendOnExpresstion(".", true)}

        //operators
        plusBtn.setOnClickListener { appendOnExpresstion("+", false)}
        minusBtn.setOnClickListener { appendOnExpresstion("-", false)}
        multiplyBtn.setOnClickListener { appendOnExpresstion("*", false)}
        devideBtn.setOnClickListener { appendOnExpresstion("/", false)}
        percentBtn.setOnClickListener { appendOnExpresstion("%", false)}

        /**
         * how to calculate percentage at kotlin sentence?
         * (problem) count, totalCount에 대해 다시 정의해야할
         * var percentBtn = (count.toDouble() / totalCount) * 100
         *
         * 위의 백분율 코드와 +/- 버튼을 활성화시키기 위해서 textView에 위치하는 숫자를 정의시키는게 좋을듯
         * 아마 계속 변화하니까 변수인 var로 정의하는게 좋을것 같다
         * 1. textView의 숫자들을 var로 정의하자
         *
         * (question) %는 그냥 숫자에 0.01을 곱해주면 되는것 아닌가??
         */

        //tvclear
        acBtn.setOnClickListener {
            textView.text = "0"
        }

        resultBtn.setOnClickListener{

                val text = textView.text.toString()
                val expression = ExpressionBuilder(textView.text.toString()).build()
                //위 코드에서 ExpressionBuilder은 build.gradle(Module: app)에
                //implementation 'net.objecthunter:exp4j:0.4.8' 의 코드 추가함
                //무슨 의미인줄은 모르고 인터넷에 찾으면서 만들어가다 보니 넣게 되었습니다.

                val result = expression.evaluate()
                val longResult = result.toLong()
                if (result == longResult.toDouble()) {
                    textView.text = longResult.toString()
                } else {
                    textView.text = result.toString()
                }
        }

    }

    /**
     * <수정해야하는 부분>
     * 1. 숫자버튼을 클릭하면 textview의 0이 사라지고 클릭한 숫자만 뜨게 수정해야함
     *      1-1 AC를 눌렀을때 '0'이 출력란에 띄워져 있어야한다. (해결)
     *      1-2 (solution) calculator 출력란에 0 떠있는 보기를 찾아보자
     * 2. '=' 표시가 현재 시뮬레이팅하면 사라져있는데 유지해야함(다른 버튼들과 차이점 알아보자)
     *      2-1 처음 시뮬레이팅하면 = 있는데 번호 버튼 누르면 사라짐(문제점 찾아보자)
     * 3. 결과값이 textview에 뜨는게 아니라 resultBtn에 뜸
     * 4. (추가해야하는거) +/- 기능이랑 % 기능 추가해야함
     *      4-1 '+/-' 버튼 클릭하면 기존 출력창에 있던 숫자에 -(음수)처리, 다시 누르면 +(양수)처리
     *      4-2 '%' 버튼은 클릭하면 기존 출력창에 있던 숫자에 백분율  ex) 1% -> 0.01
     * 5. 숫자가 한자리밖에 입력이 안 됨
     */

    fun appendOnExpresstion ( string : String, clear : Boolean){
        if(clear){
            textView.text = ""
            textView.append(string)
        }
        else{
            textView.append(string)
        }
    }
}